# Elegance Salon Backend API

This is the backend API for the Elegance Salon website, providing user authentication and other functionality.

## Features

- User registration and login
- JWT authentication
- User profile management
- RESTful API design
- CORS support for frontend integration

## Technologies Used

- Flask
- SQLAlchemy
- MySQL
- JWT for authentication
- Docker and Docker Compose for deployment

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login and get JWT token
- `GET /api/auth/profile` - Get current user profile (requires authentication)
- `PUT /api/auth/profile` - Update current user profile (requires authentication)

### User Management (Admin)

- `GET /api/users` - Get all users (requires authentication)
- `GET /api/users/<id>` - Get a specific user (requires authentication)
- `PUT /api/users/<id>` - Update a specific user (requires authentication)
- `DELETE /api/users/<id>` - Delete a specific user (requires authentication)

## Local Development

### Prerequisites

- Python 3.8+
- MySQL

### Setup

1. Clone the repository
2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Set up MySQL database:
   - Create a database named `elegance_salon`
   - Update database connection details in `src/main.py` if needed

5. Run the application:
   ```bash
   python src/main.py
   ```

The API will be available at `http://localhost:5000`.

## Deployment with Docker Compose

### Prerequisites

- Docker and Docker Compose

### Steps

1. Build and start the containers:
   ```bash
   docker-compose up -d
   ```

2. The API will be available at `http://localhost:5000`.

3. To stop the containers:
   ```bash
   docker-compose down
   ```

## Integration with Frontend

The backend is designed to work with the Elegance Salon frontend. To connect them:

1. Make sure both frontend and backend are running
2. The frontend should make API requests to `http://localhost:5000/api/...`
3. JWT tokens are returned upon successful login and should be included in the Authorization header for authenticated requests

## Environment Variables

- `DB_HOST` - Database host (default: localhost)
- `DB_PORT` - Database port (default: 3306)
- `DB_USERNAME` - Database username (default: root)
- `DB_PASSWORD` - Database password (default: password)
- `DB_NAME` - Database name (default: elegance_salon)

