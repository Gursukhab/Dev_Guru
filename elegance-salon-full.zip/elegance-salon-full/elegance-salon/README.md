# Elegance Salon Website

A modern, responsive website for a unisex salon featuring services, about us information, and user authentication.

## Features

- Responsive design that works on all devices
- Home page with hero section, featured services, about preview, and interactive service finder
- Services page with detailed service listings
- About us page with salon story, values, and team information
- Contact page with form and salon details
- Login and registration pages for user authentication

## Technologies Used

- React
- React Router
- Tailwind CSS
- Vite

## Project Structure

```
elegance-salon/
├── public/
├── src/
│   ├── assets/
│   │   └── images/
│   ├── components/
│   │   ├── about/
│   │   ├── auth/
│   │   ├── contact/
│   │   ├── home/
│   │   ├── layout/
│   │   └── services/
│   ├── pages/
│   ├── App.css
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── .gitignore
├── docker-compose.yml
├── Dockerfile
├── index.html
├── package.json
├── README.md
└── vite.config.js
```

## Deployment with Docker Compose

### Prerequisites

- Docker and Docker Compose installed on your system
- Git (optional, for cloning the repository)

### Steps to Deploy

1. Clone or download this repository to your local machine:

```bash
git clone <repository-url>
cd elegance-salon
```

2. Build and start the containers using Docker Compose:

```bash
docker-compose up -d
```

This command will:
- Build the Docker image for the frontend
- Start the container
- Map port 80 of your host to port 80 of the container

3. Access the website:

Open your browser and navigate to `http://localhost` or your server's IP address.

4. To stop the containers:

```bash
docker-compose down
```

## Development

### Prerequisites

- Node.js (v16 or higher)
- npm or pnpm

### Local Development

1. Install dependencies:

```bash
npm install
# or
pnpm install
```

2. Start the development server:

```bash
npm run dev
# or
pnpm run dev
```

3. Build for production:

```bash
npm run build
# or
pnpm run build
```

## Future Enhancements (Phase 4)

- Backend implementation with user authentication
- Database integration for storing user data and appointments
- Online booking system
- Admin dashboard for managing services and appointments

## License

This project is licensed under the MIT License - see the LICENSE file for details.

