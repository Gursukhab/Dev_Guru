import { useState } from 'react';
import { Scissors, Smile, Paintbrush, Package } from 'lucide-react';
import hairImage from '../assets/images/hair_service.png';
import skinImage from '../assets/images/skin_service.png';
import nailImage from '../assets/images/nail_service.png';

const serviceCategories = [
  {
    id: 'hair',
    title: 'Hair Services',
    icon: <Scissors className="w-6 h-6" />,
    image: hairImage,
    services: [
      { name: 'Women\'s Haircut & Style', price: '$45-65', duration: '45 min' },
      { name: 'Men\'s Haircut', price: '$25-40', duration: '30 min' },
      { name: 'Children\'s Haircut', price: '$20-30', duration: '30 min' },
      { name: 'Hair Coloring', price: '$85-150', duration: '90-120 min' },
      { name: 'Highlights', price: '$95-180', duration: '120-180 min' },
      { name: 'Balayage', price: '$150-250', duration: '150-210 min' },
      { name: 'Hair Treatment', price: '$40-80', duration: '30-60 min' },
      { name: 'Blowout', price: '$35-55', duration: '30-45 min' }
    ]
  },
  {
    id: 'skin',
    title: 'Skin Services',
    icon: <Smile className="w-6 h-6" />,
    image: skinImage,
    services: [
      { name: 'Basic Facial', price: '$60', duration: '45 min' },
      { name: 'Deluxe Facial', price: '$95', duration: '75 min' },
      { name: 'Anti-Aging Treatment', price: '$120', duration: '90 min' },
      { name: 'Chemical Peel', price: '$85-150', duration: '45-60 min' },
      { name: 'Microdermabrasion', price: '$110', duration: '60 min' },
      { name: 'Makeup Application', price: '$65-95', duration: '45-60 min' },
      { name: 'Waxing Services', price: '$15-75', duration: '15-45 min' },
      { name: 'Eyebrow Shaping', price: '$25', duration: '20 min' }
    ]
  },
  {
    id: 'nails',
    title: 'Nail Services',
    icon: <Paintbrush className="w-6 h-6" />,
    image: nailImage,
    services: [
      { name: 'Manicure', price: '$30', duration: '25 min' },
      { name: 'Pedicure', price: '$45', duration: '45 min' },
      { name: 'Gel Manicure', price: '$45', duration: '35 min' },
      { name: 'Gel Pedicure', price: '$60', duration: '55 min' },
      { name: 'Nail Art (per nail)', price: '$5-15', duration: '5-15 min' },
      { name: 'Acrylic Full Set', price: '$65', duration: '60 min' },
      { name: 'Acrylic Fill', price: '$45', duration: '45 min' },
      { name: 'Gel Nail Extensions', price: '$75', duration: '90 min' }
    ]
  },
  {
    id: 'packages',
    title: 'Special Packages',
    icon: <Package className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    services: [
      { name: 'Bridal Package', price: '$250', duration: '3 hours', description: 'Hair styling, makeup, manicure, and pedicure' },
      { name: 'Spa Day Package', price: '$180', duration: '2.5 hours', description: 'Facial, manicure, and pedicure' },
      { name: 'Couple\'s Package', price: '$320', duration: '2 hours', description: 'Side-by-side massages, facials, and manicures' },
      { name: 'Complete Makeover', price: '$350', duration: '4 hours', description: 'Hair coloring, cut, facial, makeup, and nail services' }
    ]
  }
];

const ServicesPage = () => {
  const [activeCategory, setActiveCategory] = useState('hair');

  const handleCategoryChange = (categoryId) => {
    setActiveCategory(categoryId);
    
    // Smooth scroll to the category section
    const element = document.getElementById(categoryId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Services Banner */}
      <section className="bg-secondary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Salon Services</h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto">
            Discover our comprehensive range of premium hair, skin, and nail services designed for everyone.
          </p>
        </div>
      </section>

      {/* Category Navigation */}
      <section className="sticky top-0 bg-background z-20 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex overflow-x-auto space-x-4 pb-2">
            {serviceCategories.map((category) => (
              <button
                key={category.id}
                className={`flex items-center px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                  activeCategory === category.id
                    ? 'bg-primary text-white'
                    : 'bg-muted hover:bg-muted/80'
                }`}
                onClick={() => handleCategoryChange(category.id)}
              >
                <span className="mr-2">{category.icon}</span>
                {category.title}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="section">
        <div className="container mx-auto px-4">
          {serviceCategories.map((category) => (
            <div 
              key={category.id} 
              id={category.id}
              className="mb-16 scroll-mt-20"
            >
              <div className="flex flex-col md:flex-row items-center gap-8 mb-8">
                <div className="md:w-1/3">
                  <img 
                    src={category.image} 
                    alt={category.title} 
                    className="rounded-xl shadow-md w-full h-64 object-cover"
                  />
                </div>
                <div className="md:w-2/3">
                  <div className="flex items-center mb-4">
                    <div className="p-3 rounded-full bg-primary/10 mr-4">
                      {category.icon}
                    </div>
                    <h2 className="text-3xl font-bold">{category.title}</h2>
                  </div>
                  <div className="divider ml-0 mb-6"></div>
                  <p className="text-lg text-muted-foreground mb-6">
                    {category.id === 'hair' && 'Our expert stylists provide cutting-edge haircuts, coloring, and treatments for all hair types and textures.'}
                    {category.id === 'skin' && 'Rejuvenate your skin with our range of facial treatments, professional makeup services, and skincare solutions.'}
                    {category.id === 'nails' && 'From basic manicures to elaborate nail art, our nail technicians deliver beautiful, long-lasting results.'}
                    {category.id === 'packages' && 'Experience the ultimate in pampering with our specially curated service packages designed for various occasions.'}
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-muted">
                      <th className="p-4 text-left">Service</th>
                      <th className="p-4 text-left">Duration</th>
                      <th className="p-4 text-left">Price</th>
                      {category.id === 'packages' && (
                        <th className="p-4 text-left">Description</th>
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {category.services.map((service, index) => (
                      <tr 
                        key={index} 
                        className="border-b border-muted hover:bg-muted/30 transition-colors"
                      >
                        <td className="p-4 font-medium">{service.name}</td>
                        <td className="p-4">{service.duration}</td>
                        <td className="p-4">{service.price}</td>
                        {category.id === 'packages' && (
                          <td className="p-4">{service.description}</td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-primary/10 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Book Your Appointment?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Our team of professionals is ready to help you look and feel your best. Book your appointment today!
          </p>
          <div className="flex justify-center gap-4">
            <a href="/contact" className="btn-primary">
              Book Now
            </a>
            <a href="/contact#contact-form" className="btn-secondary">
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;

