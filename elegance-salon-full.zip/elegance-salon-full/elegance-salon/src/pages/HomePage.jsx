import Hero from '../components/home/Hero';
import FeaturedServices from '../components/home/FeaturedServices';
import AboutPreview from '../components/home/AboutPreview';
import Testimonials from '../components/home/Testimonials';
import ServiceFinder from '../components/home/ServiceFinder';

const HomePage = () => {
  return (
    <>
      <Hero />
      <FeaturedServices />
      <AboutPreview />
      <ServiceFinder />
      <Testimonials />
    </>
  );
};

export default HomePage;

