import { Award, Users, Clock, Heart } from 'lucide-react';
import aboutImage from '../assets/images/about_us.png';

const teamMembers = [
  {
    name: 'Emma Thompson',
    position: 'Founder & Master Stylist',
    bio: 'With over 15 years of experience, Emma founded Elegance Salon with a vision to create a welcoming space for all clients to feel beautiful and confident.',
    expertise: 'Hair Coloring, Precision Cuts',
    image: 'https://randomuser.me/api/portraits/women/23.jpg'
  },
  {
    name: 'Michael Rodriguez',
    position: 'Senior Hair Stylist',
    bio: 'Michael brings 10 years of international styling experience to our team. His creative approach to hair design has earned him recognition in the industry.',
    expertise: 'Men\'s Styling, Textured Cuts',
    image: 'https://randomuser.me/api/portraits/men/54.jpg'
  },
  {
    name: 'Sophia Chen',
    position: 'Skincare Specialist',
    bio: 'Certified in advanced skincare techniques, Sophia is passionate about helping clients achieve their best skin through personalized treatment plans.',
    expertise: 'Facials, Anti-Aging Treatments',
    image: 'https://randomuser.me/api/portraits/women/79.jpg'
  },
  {
    name: 'David Wilson',
    position: 'Nail Technician',
    bio: 'David\'s artistic background shines through in his detailed nail art and flawless manicures. He specializes in creating unique designs for special occasions.',
    expertise: 'Nail Art, Gel Extensions',
    image: 'https://randomuser.me/api/portraits/men/32.jpg'
  }
];

const AboutPage = () => {
  return (
    <>
      {/* About Banner */}
      <section className="bg-secondary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Elegance Salon</h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto">
            Get to know our story, our team, and our commitment to excellence in beauty services.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="section">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Our Story</h2>
              <div className="w-20 h-0.5 bg-primary mb-6"></div>
              <p className="text-lg text-muted-foreground mb-6">
                Elegance Salon was founded in 2015 with a simple mission: to provide exceptional beauty services in a welcoming environment where everyone feels valued and beautiful.
              </p>
              <p className="text-lg text-muted-foreground mb-6">
                What started as a small studio with just three chairs has grown into a full-service salon with a team of dedicated professionals. Throughout our growth, we've maintained our commitment to personalized service and creating a space where clients can relax and be pampered.
              </p>
              <p className="text-lg text-muted-foreground">
                Our founder, Emma Thompson, built Elegance on the belief that beauty services should be accessible to everyone, regardless of gender, age, or background. This inclusive philosophy remains at the heart of everything we do.
              </p>
            </div>
            <div className="md:w-1/2">
              <img 
                src={aboutImage} 
                alt="Elegance Salon Team" 
                className="rounded-xl shadow-lg w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="section bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="section-heading">
            <h2 className="section-title">Our Values</h2>
            <div className="divider"></div>
            <p className="section-subtitle">
              These core principles guide everything we do at Elegance Salon.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            <div className="bg-card rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Excellence</h3>
              <p className="text-muted-foreground">
                We strive for excellence in every service we provide, using premium products and staying current with industry trends.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Inclusivity</h3>
              <p className="text-muted-foreground">
                We welcome clients of all genders, ages, and backgrounds, creating a comfortable space for everyone.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Respect</h3>
              <p className="text-muted-foreground">
                We respect our clients' time, preferences, and individuality, ensuring a personalized experience.
              </p>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-md text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Community</h3>
              <p className="text-muted-foreground">
                We believe in giving back to our community through charitable initiatives and sustainable practices.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="section">
        <div className="container mx-auto px-4">
          <div className="section-heading">
            <h2 className="section-title">Meet Our Team</h2>
            <div className="divider"></div>
            <p className="section-subtitle">
              Our talented professionals are passionate about their craft and dedicated to helping you look and feel your best.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-card rounded-xl overflow-hidden shadow-md">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                  <p className="text-primary font-medium mb-3">{member.position}</p>
                  <p className="text-muted-foreground mb-4">{member.bio}</p>
                  <div className="flex items-center">
                    <span className="text-sm font-bold mr-2">Expertise:</span>
                    <span className="text-sm text-muted-foreground">{member.expertise}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Salon Gallery */}
      <section className="section bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="section-heading">
            <h2 className="section-title">Salon Gallery</h2>
            <div className="divider"></div>
            <p className="section-subtitle">
              Take a virtual tour of our modern, welcoming salon space.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => (
              <div key={item} className="aspect-square overflow-hidden rounded-lg">
                <img 
                  src={`https://source.unsplash.com/random/300x300/?salon,${item}`} 
                  alt={`Salon Interior ${item}`} 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-primary/10 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Experience Elegance?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Book an appointment today and let our team of professionals help you look and feel your best.
          </p>
          <div className="flex justify-center gap-4">
            <a href="/contact" className="btn-primary">
              Book Now
            </a>
            <a href="/services" className="btn-secondary">
              View Services
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;

