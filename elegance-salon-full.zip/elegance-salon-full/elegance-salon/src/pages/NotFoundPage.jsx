import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';

const NotFoundPage = () => {
  return (
    <section className="section py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-9xl font-bold text-primary mb-4">404</h1>
        <h2 className="text-3xl font-bold mb-6">Page Not Found</h2>
        <p className="text-lg text-muted-foreground max-w-lg mx-auto mb-8">
          The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        
        <div className="flex flex-wrap justify-center gap-4">
          <Link to="/" className="btn-primary flex items-center">
            <Home className="mr-2 w-5 h-5" />
            Back to Home
          </Link>
          <Link to="/services" className="btn-secondary flex items-center">
            <Search className="mr-2 w-5 h-5" />
            Browse Services
          </Link>
        </div>
      </div>
    </section>
  );
};

export default NotFoundPage;

