import { Star } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    quote: 'Absolutely love this salon! The staff is incredibly professional and my hair has never looked better. The atmosphere is so relaxing and luxurious.',
    rating: 5,
    image: 'https://randomuser.me/api/portraits/women/44.jpg'
  },
  {
    id: 2,
    name: 'Michael Chen',
    quote: 'As a guy, I was a bit nervous trying a new salon, but the team at Elegance made me feel right at home. Great haircut and excellent service!',
    rating: 5,
    image: 'https://randomuser.me/api/portraits/men/32.jpg'
  },
  {
    id: 3,
    name: 'Emily Rodriguez',
    quote: 'Their nail services are top-notch! The technicians are true artists and the products they use are high quality. My manicure lasted for weeks!',
    rating: 4,
    image: 'https://randomuser.me/api/portraits/women/68.jpg'
  }
];

const Testimonials = () => {
  return (
    <section className="section bg-secondary/5">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2 className="section-title">What Our Clients Say</h2>
          <div className="divider"></div>
          <p className="section-subtitle">
            Don't just take our word for it. Here's what our valued clients have to say about their experiences at Elegance Salon.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="testimonial-card">
              <div className="testimonial-card-quote">
                {testimonial.quote}
              </div>
              <div className="testimonial-card-author">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="testimonial-card-avatar"
                />
                <div>
                  <div className="testimonial-card-name">{testimonial.name}</div>
                  <div className="testimonial-card-rating">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={16} 
                        className={i < testimonial.rating ? "star fill-current" : "star text-muted"} 
                        fill={i < testimonial.rating ? "currentColor" : "none"}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

