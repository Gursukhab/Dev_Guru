import { Link } from 'react-router-dom';
import heroImage from '../../assets/images/hero_image.png';

const Hero = () => {
  return (
    <section 
      className="hero"
      style={{ backgroundImage: `url(${heroImage})` }}
    >
      <div className="hero-overlay"></div>
      <div className="container mx-auto px-4">
        <div className="hero-content">
          <h1 className="hero-title fade-in">Experience True Elegance</h1>
          <p className="hero-subtitle fade-in">
            Premium hair, skin, and nail services for everyone in a luxurious and welcoming environment.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/services" className="btn-primary">
              Explore Services
            </Link>
            <Link to="/contact" className="btn-secondary">
              Book Appointment
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

