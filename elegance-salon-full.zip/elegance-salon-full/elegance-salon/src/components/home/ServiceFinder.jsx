import { useState } from 'react';
import { Search } from 'lucide-react';

const serviceTypes = [
  { value: 'all', label: 'All Services' },
  { value: 'hair', label: 'Hair Services' },
  { value: 'skin', label: 'Skin Services' },
  { value: 'nails', label: 'Nail Services' }
];

const durations = [
  { value: 'any', label: 'Any Duration' },
  { value: 'short', label: 'Short (< 30 min)' },
  { value: 'medium', label: 'Medium (30-60 min)' },
  { value: 'long', label: 'Long (> 60 min)' }
];

const priceRanges = [
  { value: 'any', label: 'Any Price' },
  { value: 'budget', label: 'Budget ($)' },
  { value: 'moderate', label: 'Moderate ($$)' },
  { value: 'premium', label: 'Premium ($$$)' }
];

const allServices = [
  {
    id: 1,
    name: 'Women\'s Haircut & Style',
    type: 'hair',
    duration: 'medium',
    price: 'moderate',
    priceValue: '$45-65',
    durationValue: '45 min'
  },
  {
    id: 2,
    name: 'Men\'s Haircut',
    type: 'hair',
    duration: 'short',
    price: 'budget',
    priceValue: '$25-40',
    durationValue: '30 min'
  },
  {
    id: 3,
    name: 'Hair Coloring',
    type: 'hair',
    duration: 'long',
    price: 'premium',
    priceValue: '$85-150',
    durationValue: '90-120 min'
  },
  {
    id: 4,
    name: 'Basic Facial',
    type: 'skin',
    duration: 'medium',
    price: 'moderate',
    priceValue: '$60',
    durationValue: '45 min'
  },
  {
    id: 5,
    name: 'Deluxe Facial',
    type: 'skin',
    duration: 'long',
    price: 'premium',
    priceValue: '$95',
    durationValue: '75 min'
  },
  {
    id: 6,
    name: 'Manicure',
    type: 'nails',
    duration: 'short',
    price: 'budget',
    priceValue: '$30',
    durationValue: '25 min'
  },
  {
    id: 7,
    name: 'Pedicure',
    type: 'nails',
    duration: 'medium',
    price: 'moderate',
    priceValue: '$45',
    durationValue: '45 min'
  },
  {
    id: 8,
    name: 'Gel Nail Extensions',
    type: 'nails',
    duration: 'long',
    price: 'premium',
    priceValue: '$75',
    durationValue: '90 min'
  }
];

const ServiceFinder = () => {
  const [filters, setFilters] = useState({
    type: 'all',
    duration: 'any',
    price: 'any'
  });
  
  const [results, setResults] = useState([]);
  const [searched, setSearched] = useState(false);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    
    const filteredServices = allServices.filter(service => {
      const typeMatch = filters.type === 'all' || service.type === filters.type;
      const durationMatch = filters.duration === 'any' || service.duration === filters.duration;
      const priceMatch = filters.price === 'any' || service.price === filters.price;
      
      return typeMatch && durationMatch && priceMatch;
    });
    
    setResults(filteredServices);
    setSearched(true);
  };

  return (
    <section className="section">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2 className="section-title">Find Your Perfect Service</h2>
          <div className="divider"></div>
          <p className="section-subtitle">
            Use our interactive service finder to discover the perfect treatment based on your preferences.
          </p>
        </div>

        <div className="service-finder max-w-4xl mx-auto">
          <form onSubmit={handleSearch} className="service-finder-form">
            <div className="service-finder-input">
              <label htmlFor="type" className="input-label">Service Type</label>
              <select 
                id="type" 
                name="type" 
                className="form-select"
                value={filters.type}
                onChange={handleFilterChange}
              >
                {serviceTypes.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="service-finder-input">
              <label htmlFor="duration" className="input-label">Duration</label>
              <select 
                id="duration" 
                name="duration" 
                className="form-select"
                value={filters.duration}
                onChange={handleFilterChange}
              >
                {durations.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="service-finder-input">
              <label htmlFor="price" className="input-label">Price Range</label>
              <select 
                id="price" 
                name="price" 
                className="form-select"
                value={filters.price}
                onChange={handleFilterChange}
              >
                {priceRanges.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button type="submit" className="btn-primary flex items-center">
                <Search size={18} className="mr-2" />
                Find Services
              </button>
            </div>
          </form>

          {searched && (
            <div className="mt-8">
              <h3 className="text-xl font-bold mb-4">
                {results.length > 0 
                  ? `Found ${results.length} service${results.length !== 1 ? 's' : ''}` 
                  : 'No services found'}
              </h3>
              
              {results.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted">
                        <th className="p-3 text-left">Service</th>
                        <th className="p-3 text-left">Duration</th>
                        <th className="p-3 text-left">Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map(service => (
                        <tr key={service.id} className="border-b border-muted">
                          <td className="p-3">{service.name}</td>
                          <td className="p-3">{service.durationValue}</td>
                          <td className="p-3">{service.priceValue}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ServiceFinder;

