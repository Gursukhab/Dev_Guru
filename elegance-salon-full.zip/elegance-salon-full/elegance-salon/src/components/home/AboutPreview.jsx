import { Link } from 'react-router-dom';
import aboutImage from '../../assets/images/about_us.png';

const AboutPreview = () => {
  return (
    <section className="section">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <h2 className="text-4xl font-bold mb-4">About Elegance Salon</h2>
            <div className="w-20 h-0.5 bg-primary mb-6"></div>
            <p className="text-lg text-muted-foreground mb-6">
              Welcome to Elegance Salon, where beauty meets luxury. Our team of skilled professionals is dedicated to providing exceptional services tailored to your unique style and preferences.
            </p>
            <p className="text-lg text-muted-foreground mb-6">
              Founded in 2015, we've built our reputation on quality, creativity, and customer satisfaction. Our mission is to help every client look and feel their absolute best.
            </p>
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                  <span className="text-primary font-bold">10+</span>
                </div>
                <span className="font-medium">Expert Stylists</span>
              </div>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                  <span className="text-primary font-bold">50+</span>
                </div>
                <span className="font-medium">Services Offered</span>
              </div>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                  <span className="text-primary font-bold">8+</span>
                </div>
                <span className="font-medium">Years Experience</span>
              </div>
            </div>
            <Link to="/about" className="btn-secondary">
              Learn More About Us
            </Link>
          </div>
          <div className="md:w-1/2">
            <img 
              src={aboutImage} 
              alt="Elegance Salon Team" 
              className="rounded-xl shadow-lg w-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPreview;

