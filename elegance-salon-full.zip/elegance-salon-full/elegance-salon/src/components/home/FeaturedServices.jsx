import { Link } from 'react-router-dom';
import { Scissors, Smile, Paintbrush } from 'lucide-react';
import hairImage from '../../assets/images/hair_service.png';
import skinImage from '../../assets/images/skin_service.png';
import nailImage from '../../assets/images/nail_service.png';

const services = [
  {
    id: 1,
    title: 'Hair Services',
    description: 'Expert cuts, styling, coloring, and treatments for all hair types and textures.',
    image: hairImage,
    icon: <Scissors className="w-6 h-6" />,
    link: '/services#hair'
  },
  {
    id: 2,
    title: 'Skin Services',
    description: 'Rejuvenating facials, skin treatments, and professional makeup application.',
    image: skinImage,
    icon: <Smile className="w-6 h-6" />,
    link: '/services#skin'
  },
  {
    id: 3,
    title: 'Nail Services',
    description: 'Luxurious manicures, pedicures, and artistic nail designs for any occasion.',
    image: nailImage,
    icon: <Paintbrush className="w-6 h-6" />,
    link: '/services#nails'
  }
];

const FeaturedServices = () => {
  return (
    <section className="section bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2 className="section-title">Our Featured Services</h2>
          <div className="divider"></div>
          <p className="section-subtitle">
            Discover our most popular services designed to enhance your natural beauty and provide a relaxing experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="service-card">
              <img 
                src={service.image} 
                alt={service.title} 
                className="w-full h-64 object-cover"
              />
              <div className="service-card-content">
                <div className="flex items-center mb-2">
                  <div className="p-2 rounded-full bg-primary/10 mr-3">
                    {service.icon}
                  </div>
                  <h3 className="service-card-title">{service.title}</h3>
                </div>
                <p className="service-card-description">
                  {service.description}
                </p>
                <Link to={service.link} className="btn-text">
                  Learn More
                </Link>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/services" className="btn-primary">
            View All Services
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedServices;

