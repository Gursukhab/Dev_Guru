import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail, Clock } from 'lucide-react';
import salonLogo from '../../assets/images/salon_logo.png';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container mx-auto px-4">
        <div className="footer-content">
          <div className="footer-column">
            <Link to="/">
              <img src={salonLogo} alt="Elegance Salon" className="h-16 mb-4" />
            </Link>
            <p className="text-white/80 mb-6">
              Elegance Salon offers premium hair, skin, and nail services for all genders in a luxurious and welcoming environment.
            </p>
            <div className="footer-social">
              <a href="#" className="footer-social-icon" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="footer-social-icon" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="footer-social-icon" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          <div className="footer-column">
            <h3 className="footer-title">Quick Links</h3>
            <ul className="footer-links">
              <li>
                <Link to="/" className="footer-link">Home</Link>
              </li>
              <li>
                <Link to="/services" className="footer-link">Services</Link>
              </li>
              <li>
                <Link to="/about" className="footer-link">About Us</Link>
              </li>
              <li>
                <Link to="/contact" className="footer-link">Contact</Link>
              </li>
              <li>
                <Link to="/login" className="footer-link">Login</Link>
              </li>
              <li>
                <Link to="/register" className="footer-link">Register</Link>
              </li>
            </ul>
          </div>

          <div className="footer-column">
            <h3 className="footer-title">Services</h3>
            <ul className="footer-links">
              <li>
                <Link to="/services#hair" className="footer-link">Hair Services</Link>
              </li>
              <li>
                <Link to="/services#skin" className="footer-link">Skin Services</Link>
              </li>
              <li>
                <Link to="/services#nails" className="footer-link">Nail Services</Link>
              </li>
              <li>
                <Link to="/services#packages" className="footer-link">Special Packages</Link>
              </li>
            </ul>
          </div>

          <div className="footer-column">
            <h3 className="footer-title">Contact Info</h3>
            <ul className="footer-links">
              <li className="flex items-center mb-3 text-white/80">
                <MapPin size={18} className="mr-2" />
                <span>123 Salon Street, City, State 12345</span>
              </li>
              <li className="flex items-center mb-3 text-white/80">
                <Phone size={18} className="mr-2" />
                <span>(123) 456-7890</span>
              </li>
              <li className="flex items-center mb-3 text-white/80">
                <Mail size={18} className="mr-2" />
                <span>info@elegancesalon.com</span>
              </li>
              <li className="flex items-center mb-3 text-white/80">
                <Clock size={18} className="mr-2" />
                <span>Mon-Fri: 9am-8pm<br />Sat: 9am-6pm<br />Sun: 10am-4pm</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>Copyright © {new Date().getFullYear()} Elegance Salon. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

