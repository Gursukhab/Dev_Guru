# Elegance Salon - Full Stack Application

This repository contains both the frontend and backend components of the Elegance Salon website.

## Project Structure

- `elegance-salon/` - React frontend application
- `elegance-salon-backend/` - Flask backend API
- `docker-compose.yml` - Combined Docker Compose file for deploying the entire application

## Features

### Frontend
- Responsive design that works on all devices
- Home page with hero section, featured services, about preview, and interactive service finder
- Services page with detailed service listings
- About us page with salon story, values, and team information
- Contact page with form and salon details
- Login and registration pages for user authentication

### Backend
- User registration and login
- JWT authentication
- User profile management
- RESTful API design
- CORS support for frontend integration

## Deployment with Docker Compose

### Prerequisites

- Docker and Docker Compose installed on your system
- Git (optional, for cloning the repository)

### Steps to Deploy

1. Clone or download this repository to your local machine:

```bash
git clone <repository-url>
cd elegance-salon-project
```

2. Build and start the containers using Docker Compose:

```bash
docker-compose up -d
```

This command will:
- Build the Docker images for the frontend and backend
- Start the containers
- Set up the MySQL database
- Connect all services together

3. Access the website:

- Frontend: Open your browser and navigate to `http://localhost` or your server's IP address
- Backend API: Available at `http://localhost:5000/api`

4. To stop the containers:

```bash
docker-compose down
```

## Development

For development instructions, please refer to the README files in the respective directories:

- [Frontend README](./elegance-salon/README.md)
- [Backend README](./elegance-salon-backend/README.md)

## Technologies Used

### Frontend
- React
- React Router
- Tailwind CSS
- Vite

### Backend
- Flask
- SQLAlchemy
- MySQL
- JWT for authentication

## License

This project is licensed under the MIT License - see the LICENSE file for details.

